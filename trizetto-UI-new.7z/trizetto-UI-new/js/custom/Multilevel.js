var app=angular.module("HomePageView");
var mainfunction = function ($scope,$http,$httpParamSerializerJQLike,$location,$window,$route,$mdToast,$mdDialog,AppData) {
	 $scope.gridOptions = {
            data: [],
            urlSync: false
        };
		$scope.gridActions = {};
		$scope.entities =[
                { name: "Applications"},
                { name: "Layouts" },
				{ name: "Procedures" },
				{ name: "Procedure Sequences" },
				{ name: "Segments" },
				{ name: "Fields" },
				{ name: "Files" },
				{ name: "Formats" },
				{ name: "Functions" },
				{ name: "Modules" },
				{ name: "Param expressions" },
				{ name: "Parameters" }				
            ];
			$scope.clear = function() {
        $scope.request = "";
    };
	
	$scope.showCustomToast = function(value) {
		console.log("toast called")
        $mdToast.show({
          hideDelay   : 2000,
          position    : 'top right',
          controller  : function($scope, $mdToast){
		$scope.message = value;
		console.log("message"+$scope.message)
	  },
          template : '<md-toast>'+
					'<span class="md-toast-text" flex>{{message}}</span>'+
					'<md-button ng-click="closeToast()">'+
						'Close'+
					'</md-button>'+
					'</md-toast>'
        });
      };
			$scope.properties = {
							 Applications: {
							  getAllUrl: "https://angular-data-grid.github.io/demo/data.json",
							  getAllDataDialogueTemplate: "Application/ViewAllAppDataDialogue.html",
							  getDataByIdDialogueTemplate: "Application/ViewAppByIdDialogue.html",
							  createEntityDialogueTemplate: "Application/CreateAppDialogue.html",
							  createEntityUrl: "https://angular-data-grid.github.io/demo/data.json",
							  createAppResponseDialogueTemplate: "Application/CreateAppResponseDialogue.html"
							  
							 },
							 Layouts: {},
							 Files: {
							  getAllUrl: "https://angular-data-grid.github.io/demo/data.json",
							  getAllDataDialogueTemplate: "File/ViewAllFileDataDialogue.html",
							  getDataByIdDialogueTemplate: "File/ViewFileByIdDialogue.html",
							  createEntityDialogueTemplate: "File/CreateFileDialogue.html",
							  createEntityUrl: "https://angular-data-grid.github.io/demo/data.json",
							  createAppResponseDialogueTemplate: "File/CreateFileResponseDialogue.html"
							 },
							 Formats: {
							  getAllUrl: "https://angular-data-grid.github.io/demo/data.json",
							  getAllDataDialogueTemplate: "Format/ViewAllFormatDataDialogue.html",
							  getDataByIdDialogueTemplate: "Format/ViewFormatByIdDialogue.html",
							  createEntityDialogueTemplate: "Format/CreateFormatDialogue.html",
							  createEntityUrl: "https://angular-data-grid.github.io/demo/data.json",
							  createAppResponseDialogueTemplate: "Format/CreateFormatResponseDialogue.html"
							 },
							 Functions: {
							  getAllUrl: "http://10.227.85.208:8071/framework/functions",
							  getByIdUrl: "http://10.227.85.208:8071/framework/functions/",
							  getAllDataDialogueTemplate: "Function/ViewAllFunctionDataDialogue.html",
							  getDataByIdDialogueTemplate: "Function/ViewFunctionByIdDialogue.html",
							  createEntityDialogueTemplate: "Function/CreateFunctionDialogue.html",
							  createEntityUrl: "http://10.227.85.208:8071/framework/functions",
							  createAppResponseDialogueTemplate: "Function/CreateFunctionResponseDialogue.html"
							 },
							 Modules: {
							  getAllUrl: "https://angular-data-grid.github.io/demo/data.json",
							  getAllDataDialogueTemplate: "Module/ViewAllModuleDataDialogue.html",
							  getDataByIdDialogueTemplate: "Module/ViewModuleByIdDialogue.html",
							  createEntityDialogueTemplate: "Module/CreateModuleDialogue.html",
							  createEntityUrl: "https://angular-data-grid.github.io/demo/data.json",
							  createAppResponseDialogueTemplate: "Module/CreateModuleResponseDialogue.html"
							 },
							 

							};
					  
			
		$scope.getData = function(value, ev) {

    switch (value.name) {
        case 'Applications':
            $scope.getAllData(value, ev,$scope.properties.Applications)
            break;
        case 'Files':
            $scope.getAllData(value, ev,$scope.properties.Files);
            break;
			case 'Formats':
            $scope.getAllData(value, ev,$scope.properties.Formats);
            break;
			case 'Functions':
            $scope.getAllData(value, ev,$scope.properties.Functions);
            break;
			case 'Modules':
            $scope.getAllData(value, ev,$scope.properties.Modules);
            break;
			case '2':
            alert("Selected Case Number is 2");
            break;
        default:

    }
}
$scope.getAllData = function(value, ev,prop) {
	console.log(prop.getAllUrl);
	//alert(value.getAllUrl)
    $scope.value = null
    $http({
        method: 'GET',
        url: prop.getAllUrl,
    }).then(
        function(response) {
            value = response.data;
            AppData.addAllData(value);
            $scope.getAllDataDialogue(value, ev,prop);
        },
        function(response) {}
    );
}

$scope.getAllDataDialogue = function(value, ev,prop) {
    $scope.request = value;
    $mdDialog.show({
        clickOutsideToClose: true,
        scope: $scope,
        preserveScope: true,
        parent: angular.element(document.body),
        targetEvent: ev,
        templateUrl: prop.getAllDataDialogueTemplate,
        controller: function DialogController($scope, $mdDialog) {

            $scope.gridOptions.data = AppData.getAllData();
            $scope.gridActions = {};
            console.log(AppData.getAllData());
            $scope.closeDialog = function() {
                $mdDialog.hide();
            }
            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }
    });
}

$scope.showDetails = function(value, ev,selector) {
	var template = null;
	$scope.request = value;
    //$scope.getAppDataById($scope.request.code);
	//alert(selector)
	switch (selector) {
        case 'Applications':

            $scope.getAppDataById($scope.request.code, ev,$scope.properties.Applications)
            break;
        case 'Files':
            $scope.getAppDataById($scope.request.code, ev,$scope.properties.Files);
            break;
			case 'Formats':
            $scope.getAppDataById($scope.request.code, ev,$scope.properties.Formats);
            break;
			case 'Functions':
            $scope.getFunctionDataById($scope.request.id, ev,$scope.properties.Functions);
            break;
			case 'Modules':
            $scope.getAppDataById($scope.request.code, ev,$scope.properties.Modules);
            break;
			case '2':
            alert("Selected Case Number is 2");
            break;
        default:
    
    console.log("from getById " + AppData.getDataById())
    
};
}
$scope.getAppDataById = function(id,ev,prop) {
    $scope.value = null
    $http({
        method: 'GET',
        url: 'https://angular-data-grid.github.io/demo/data.json',
    }).then(
        function(response) {
            value = response.data[0];
            console.log(value);
            AppData.addDataById(value);
			$scope.responseData = AppData.getDataById();
			$mdDialog.show({
        clickOutsideToClose: true,
        scope: $scope,
        preserveScope: true,
        parent: angular.element(document.body),
        targetEvent: ev,
        templateUrl: prop.getDataByIdDialogueTemplate,
        controller: function DialogController($scope, $mdDialog) {

            $scope.closeDialog = function() {
                $mdDialog.hide();
            }
            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }
    });
        },
        function(response) {}
    );
}
$scope.getFunctionDataById = function(id,ev,prop) {

    $scope.value = null
    $http({
        method: 'GET',
        url: prop.getByIdUrl+id,
    }).then(
        function(response) {
            value = response.data;
            console.log(value);
            AppData.addDataById(value);
			$scope.responseData = AppData.getDataById();
			$mdDialog.show({
        clickOutsideToClose: true,
        scope: $scope,
        preserveScope: true,
        parent: angular.element(document.body),
        targetEvent: ev,
        templateUrl: prop.getDataByIdDialogueTemplate,
        controller: function DialogController($scope, $mdDialog) {

            $scope.closeDialog = function() {
                $mdDialog.hide();
            }
            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }
    });
        },
        function(response) {}
    );
}

$scope.create = function(ev,value) {
switch (value.name) {
        case 'Applications':

            $scope.createEntity(ev,$scope.properties.Applications)
            break;
        case 'Files':
            $scope.createEntity(ev,$scope.properties.Files);
            break;
			case 'Formats':
            $scope.createEntity( ev,$scope.properties.Formats);
            break;
			case 'Functions':
            $scope.createFunctionEntity(ev,$scope.properties.Functions);
            break;
			case 'Modules':
            $scope.createEntity(ev,$scope.properties.Modules);
            break;
			case '2':
            alert("Selected Case Number is 2");
            break;
        default:
    
    console.log("from getById " + AppData.getDataById())
    
};
        
    };
	$scope.createEntity = function(ev,prop) {
	$scope.request;
      $mdDialog.show({
                  clickOutsideToClose: true,
                  scope: $scope,        
                  preserveScope: true, 
				  parent: angular.element(document.body),
				  targetEvent: ev,				  
                  templateUrl: prop.createEntityDialogueTemplate,
                  controller: function DialogController($scope, $mdDialog) {				  
				  var message = "Successfully created"
					$scope.createData = function(request){
					console.log("from create"+request);
					$http({
	  				method : 'GET',
	  				url : prop.createEntityUrl,
					}).then(
	  				       function(response){
						   $scope.value = response.data;
						   //$scope.initialvalue = AppData.getAllData();
							//alert($scope.value)
						   //$scope.initialvalue.push(response.data[0])
						    //console.log($scope.initialvalue)
						    //AppData.addAllData($scope.initialvalue)
							//console.log(AppData.getAllData());
							//$scope.gridOptions.data = AppData.getAllData();
								$mdDialog.cancel();
								$scope.createResponseDialogue($scope.value,ev,prop)
								$scope.showCustomToast(message);
	  				         },
	  				         function(response){
	  				         }
	  				      );
		            }
                     $scope.closeDialog = function() {
                        $mdDialog.hide();
                     }
					 $scope.cancel = function() {
					  $mdDialog.cancel();
					};
                  }
               });}
			   
			   
			   $scope.createFunctionEntity = function(ev,prop) {
	$scope.request;
      $mdDialog.show({
                  clickOutsideToClose: true,
                  scope: $scope,        
                  preserveScope: true, 
				  parent: angular.element(document.body),
				  targetEvent: ev,				  
                  templateUrl: prop.createEntityDialogueTemplate,
                  controller: function DialogController($scope, $mdDialog) {				  
				  var message = "Successfully created"
					$scope.createData = function(request){
					var input = JSON.stringify(request);
					console.log(input)
					console.log("from create"+request);
					$http({
	  				method : 'POST',
	  				url : prop.createEntityUrl,
					data : input,
			headers : {
				'Content-Type' : 'application/json'
			}
					}).then(
	  				       function(response){
						   $scope.value = response.data;
						   console.log("after response----"+response.data)
						   //$scope.initialvalue = AppData.getAllData();
							//alert($scope.value)
						   //$scope.initialvalue.push(response.data[0])
						    //console.log($scope.initialvalue)
						    //AppData.addAllData($scope.initialvalue)
							//console.log(AppData.getAllData());
							//$scope.gridOptions.data = AppData.getAllData();
								$mdDialog.cancel();
								$scope.createResponseDialogue1($scope.value,ev,prop)
								$scope.showCustomToast(message);
	  				         },
	  				         function(response){
	  				         }
	  				      );
		            }
                     $scope.closeDialog = function() {
                        $mdDialog.hide();
                     }
					 $scope.cancel = function() {
					  $mdDialog.cancel();
					};
                  }
               });}
			   $scope.createResponseDialogue1 = function(value,ev,prop){
	
	$mdDialog.show({
        clickOutsideToClose: true,
        scope: $scope,
        preserveScope: true,
        parent: angular.element(document.body),
        targetEvent: ev,
        templateUrl: prop.createAppResponseDialogueTemplate,
        controller: function DialogController($scope, $mdDialog) {
			$scope.responseData = value;
            $scope.closeDialog = function() {
                $mdDialog.hide();
            }
            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }
    });}
			   
			   
	$scope.createResponseDialogue = function(value,ev,prop){
	
	$mdDialog.show({
        clickOutsideToClose: true,
        scope: $scope,
        preserveScope: true,
        parent: angular.element(document.body),
        targetEvent: ev,
        templateUrl: prop.createAppResponseDialogueTemplate,
        controller: function DialogController($scope, $mdDialog) {
			$scope.responseData = value[0];
            $scope.closeDialog = function() {
                $mdDialog.hide();
            }
            $scope.cancel = function() {
                $mdDialog.cancel();
            };
        }
    });}

}
app.controller("Multilevel", mainfunction)