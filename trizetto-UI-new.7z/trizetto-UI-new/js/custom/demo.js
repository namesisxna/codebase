var app=angular.module("HomePageView");
var mainfunction = function ($scope,$http,$httpParamSerializerJQLike,$location,$window,$route,$mdToast,$mdDialog,AppData) {
	 
 $scope.clear = function () {
        $scope.request = "";
    };		
$scope.submit = function(value) {
var request = JSON.stringify(value)
alert(request);
console.log(request)
   
    
}


}

app.controller("demoCon", mainfunction)