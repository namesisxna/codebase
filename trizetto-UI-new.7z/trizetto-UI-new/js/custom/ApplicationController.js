var app=angular.module("HomePageView");
var mainfunction = function ($scope, $http,$mdDialog,ngClipboard,$mdToast,$location,$window,AppData) {
		$scope.dateFrom = new Date();
		$scope.myData = []
		$scope.gridOptions = {
            data: [],
            urlSync: false
        };
		$scope.gridOptions.data = AppData.getAllData();
		$scope.$watch('gridOptions.data', function () {console.log("watcher called")});
		$scope.showCustomToast = function(value) {
		console.log("toast called")
        $mdToast.show({
          hideDelay   : 3000,
          position    : 'top right',
          controller  : function($scope, $mdToast){
		$scope.message = value;
		console.log("message"+$scope.message)
	  },
          template : '<md-toast>'+
					'<span class="md-toast-text" flex>{{message}}</span>'+
					'<md-button ng-click="closeToast()">'+
						'Close'+
					'</md-button>'+
					'</md-toast>'
        });
      };	  
		$scope.getAllAppData = function(){
	  		$scope.value=null
		  		$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
	  			}).then(
	  				       function(response){
							   value = response.data;
							   AppData.addAllData(value);
							   window.location = "#/Application";
	  				         },
	  				         function(response){
	  				         }
	  				      );
		}		
	$scope.getDataById = function(id){		
	  		$scope.value=null
		  		$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
	  			}).then(
	  				       function(response){
							   value = response.data[0];
							   console.log(value);
							   AppData.addDataById(value);
	  				         },
	  				         function(response){
	  				         }
	  				      );
	}	
	$scope.showAlert = function() {
		 alert = $mdDialog.alert()
        .title('Attention, ' + $scope.userName)
        .textContent('This is an example of how easy dialogs can be!')
        .ok('Close');

      $mdDialog
          .show( alert )
          .finally(function() {
            alert = undefined;
          });
    }		
	$scope.showDetails = function(value,ev) {
		$scope.appflag=true;
		$scope.request = value;
		$scope.getDataById($scope.request.code);
		console.log("from getById "+AppData.getDataById())
		$scope.message = "Sucessfully Deleted";
      $mdDialog.show({
                  clickOutsideToClose: true,
                  scope: $scope,        
                  preserveScope: true, 
				  parent: angular.element(document.body),
				  targetEvent: ev,				  
                  template: '<md-dialog  class="userDetailsWrap" aria-label="Details">'+
							  '<form ng-cloak>'+
								'<md-toolbar>'+
								  '<div class="md-toolbar-tools">'+
								  '<h2 style="color:#FFFFFF;">Details</h2>'+
								  '<span flex></span>'+
								  '<md-button class="md-icon-button" ng-click="cancel()">'+
									 '<md-icon md-svg-src="img/icons/ic_close_24px.svg" aria-label="Close dialog"></md-icon>'+
									'</md-button>'+
									'</div>'+
							'</md-toolbar>'+
							'<md-dialog-content>'+
							  '<div class="md-dialog-content">'+
							  '<md-content class="md-padding">'+
							  '<md-list-item class="md-1-line">'+
								'<div class="md-list-item-text" layout="column">'+
							   ' <span spanclass="md-subhead"><p><b userlabel>Application Id:</b>&nbsp;&nbsp;{{request.code}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Name:&nbsp;&nbsp;</b>{{request.statusDisplay}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Status:&nbsp;&nbsp;</b>{{request.statusDisplay}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Create User:&nbsp;&nbsp;</b>{{request.code}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Create Date:&nbsp;&nbsp;</b>{{request.placed}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Update User:&nbsp;&nbsp;</b>{{request.code}}</p></span>'+
								' <span spanclass="md-subhead"><p><b userlabel>Update Date:&nbsp;&nbsp;</b>{{request.placed}}</p></span></div>'+
								'<p>'+
									'<md-button style="margin-top: 10px; "class="md-fab md-fab-top-right md-accent md-hue-2" '+ 
									'aria-label="copy accesstoken" ng-click="update(request,$event)"> '+
									'<md-icon md-svg-icon="../trizetto-UI/img/icons/ic_update_black_24px.svg"></md-icon>'	+
									'<md-tooltip md-direction="bottom">update</md-tooltip></p>'+
								'<p>'+
									'<md-button style="margin-top: 10px; "class="md-fab md-fab-bottom-right md-accent md-hue-2"'+ 
									'aria-label="copy accesstoken" ng-click="showCustomToast(message);cancel()"> '+
									'<md-icon md-svg-icon="../trizetto-UI/img/icons/ic_delete_forever_black_24px.svg"></md-icon>'	+
									'<md-tooltip md-direction="bottom">delete</md-tooltip></p>'+			
							   '</md-list-item>'+
							   '</md-content>'+
							'</md-dialog-content>'+
						  '</form>'+
						'</md-dialog>',
                  controller: function DialogController($scope, $mdDialog) {

                     $scope.closeDialog = function() {
                        $mdDialog.hide();
                     }
					 $scope.cancel = function() {
					  $mdDialog.cancel();
					};
                  }
               });
    };
    $scope.create = function(ev) {
        $scope.request;
      $mdDialog.show({
                  clickOutsideToClose: true,
                  scope: $scope,        
                  preserveScope: true, 
				  parent: angular.element(document.body),
				  targetEvent: ev,				  
                  template: '<md-dialog flex-gt-xs=30 aria-label="Create">'+
							  '<form ng-cloak >'+
								'<md-toolbar>'+
								  '<div class="md-toolbar-tools">'+
								  '<h2 style="color:#FFFFFF;">Create</h2>'+
								  '<span flex></span>'+
								  '<md-button class="md-icon-button" ng-click="cancel()">'+
									 '<md-icon md-svg-src="img/icons/ic_close_24px.svg" aria-label="Close dialog"></md-icon>'+
									'</md-button>'+
									'</div>'+
								'</md-toolbar>'+
								  '<md-input-container class="md-icon-float md-block" flex-gt-sm style="margin-top: 40px">'+
									  '<label>Name</label>'+
													  '<input type="text" ng-model="request.name" required>'+
													  '<div ng-messages="loginForm.username.$error">'+
													  '<div ng-message="required">* this field is required</div>'+
													  '</div>'+
									'</md-input-container>'+							
									'<div layout="row" layout-align="center end">'+
										'<md-button  class="md-raised md-primary md-hue-2" ng-click="createData(request)" flex="15">Submit</md-button>'+
									'</div>'+
							  '</form>'+
							'</md-dialog>',
                  controller: function DialogController($scope, $mdDialog) {				  
				  var message = "Successfully created"
					$scope.createData = function(request){
					console.log("from create"+request.status);
					$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
					}).then(
	  				       function(response){
						   
						   $scope.initialvalue = AppData.getAllData();
						   
						   $scope.initialvalue.push(response.data[0])
						    //console.log($scope.initialvalue)
						    AppData.addAllData($scope.initialvalue)
							console.log(AppData.getAllData());
							$scope.gridOptions.data = AppData.getAllData();
								$mdDialog.cancel();
								$scope.showCustomToast(message);
								window.location = "#/Application";
	  				         },
	  				         function(response){
	  				         }
	  				      );
		            }
                     $scope.closeDialog = function() {
                        $mdDialog.hide();
                     }
					 $scope.cancel = function() {
					  $mdDialog.cancel();
					};
                  }
               });
    };
  $scope.update = function(value,ev) {
       $scope.request = value;
     $mdDialog.show({
                  clickOutsideToClose: true,
                  scope: $scope,        
                  preserveScope: true, 
				  parent: angular.element(document.body),
				  targetEvent: ev,				  
                  template: '<md-dialog flex-gt-xs=30 aria-label="Update">'+
							  '<form ng-cloak >'+
								'<md-toolbar>'+
								  '<div class="md-toolbar-tools">'+
								  '<h2 style="color:#FFFFFF;">Update</h2>'+
								  '<span flex></span>'+
								  '<md-button class="md-icon-button" ng-click="cancel()">'+
									'<md-icon md-svg-src="img/icons/ic_close_24px.svg" aria-label="Close dialog"></md-icon>'+
								  '</md-button>'+
									'</div>'+
								'</md-toolbar>'+			  
								  '<md-input-container class="md-block" flex-gt-sm style="margin-top: 40px">'+
									  '<label>Id</label>'+
													  '<input type="text" ng-model="request.code" disabled>'+
									'</md-input-container>'+
									'<md-input-container class="md-block" flex-gt-sm >'+
									  '<label>Name</label>'+
													  '<input type="text" ng-model="request.statusDisplay" required>'+
									'</md-input-container>'+
								   '<md-input-container class="md-block" flex-gt-sm >'+
									  '<label>Status</label>'+
													  '<input type="text" ng-model="request.statusDisplay" required>'+
									'</md-input-container>'+
									'<md-input-container class="md-block" flex-gt-sm >'+
									  '<label>Create User</label>'+
													  '<input type="text" ng-model="request.code" required>'+
									'</md-input-container>'+									
									'<md-input-container class="md-block" flex-gt-sm>'+
									  '<label>Create Date(mm/dd/yyyy)</label>'+
													  '<input type="text" ng-model="request.placed" required>'+
									'</md-input-container>'+
									'<md-input-container class="md-block" flex-gt-sm >'+
									  '<label>Update User</label>'+
													  '<input type="text" ng-model="request.code" required>'+
									'</md-input-container>'+
									'<md-input-container class="md-block" flex-gt-sm>'+
									  '<label>Update Date(mm/dd/yyyy)</label>'+
													  '<input type="text" ng-model="request.placed" required>'+
									'</md-input-container>'+
									
									'<div layout="row" layout-align="center end">'+
										'<md-button  class="md-raised md-primary md-hue-2" flex="15" ng-click="updateData(request)">Submit</md-button>'+
									'</div>'+
							  '</form>'+
							'</md-dialog>',
                  controller: function DialogController($scope, $mdDialog) {
				  var message = "Successfully updated"
					$scope.updateData = function(request){
					console.log(request.statusDisplay);
					$scope.value=null
					$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
					}).then(
	  				       function(response){
								$mdDialog.cancel();
								$scope.showCustomToast(message)
	  				         },
	  				         function(response){
	  				         }
	  				      );
		            }

                     $scope.closeDialog = function() {
                        $mdDialog.hide();
                     }
					 $scope.cancel = function() {
					  $mdDialog.cancel();
					};
                  }
               });
    }
}	
app.controller('AppController', mainfunction)