(function(){
 var app=angular.module('HomePageView', ['ngRoute' ,'ngMdIcons','ngMaterial','dataGrid', 'pagination','ngMessages']);

app.config(function($mdAriaProvider) {
   // Globally disables all ARIA warnings.
   $mdAriaProvider.disableWarnings();
});

app.config(function($routeProvider) {
    $routeProvider
//    .when("/Home" ,{
//  	 templateUrl: "Index.html",  
//        controller: "HomePageController" 
//    })
	.when("/Application", {  
        templateUrl: "Application.html",  
        controller: "AppController"
		
    })
	 .when("/Module", {  
        templateUrl: "Module.html",  
        controller: "ModuleController"
		
    })
	.when("/File", {  
        templateUrl: "File.html",  
        controller: "FileController"
		
    })
	.when("/Format", {  
        templateUrl: "Format.html",  
        controller: "FormatController"
		
    })
	.when("/Function", {  
        templateUrl: "Function.html",  
        controller: "FunctionController"
		
    })

    .when("/Profile", {  
        templateUrl: "Profile.html",  
        controller: "ProfileController"
		
    })
    .when("/ManageUsers", {  
        templateUrl: "ManageUsers.html",  
        controller: "UserController"  
    })
    .when("/Subscription", {  
        templateUrl: "Subscription.html",  
        controller: "SubscriptionController"  
    })
     .when("/Service", {  
        templateUrl: "Service.html",  
        controller: "ServiceController"  
    })
    .when("/ViewService", {  
        templateUrl: "ViewService.html",  
        controller: "ViewServiceController"  
    })
     .when("/ManageService", {  
        templateUrl: "ManageService.html",  
        controller: "ManageServiceController"  
    })
     .when("/Flow", {  
        templateUrl: "Flow.html",  
        controller: "FlowController"  
    })
      .when("/Destination", {  
        templateUrl: "Destination.html",  
        controller: "DestinationController"  
    })
     .when("/FlightInfoService", {  
        templateUrl: "FlightInfoService.html",  
        controller: "FlightInfoServiceController"  
    })
    .when("/AdministrationService", {  
        templateUrl: "AdministrationService.html",  
        controller: "AdministrationServiceController"  
    })
        .when("/TravelInfoService", {  
        templateUrl: "TravelInfoService.html",  
        controller: "TravelInfoServiceController"  
    })
    .when("/AirlineInfoService", {  
        templateUrl: "AirlineInfoService.html",  
        controller: "AirlineInfoServiceController"  
    })
    .when("/WeatherInfoService", {  
        templateUrl: "WeatherInfoService.html",  
        controller: "WeatherInfoServiceController"  
    })
    .when("/TransportInfoService", {  
        templateUrl: "TransportInfoService.html",  
        controller: "TransportInfoServiceController"  
    })
    .when("/FlightConnectionService", {  
        templateUrl: "FlightConnectionService.html",  
        controller: "FlightConnectionServiceController"  
    })
    .when("/MessageBroadcastService", {  
        templateUrl: "MessageBroadcastService.html",  
        controller: "MessageBroadcastServiceController"  
    })
    .when("/AirportInfoService", {  
        templateUrl: "AirportInfoService.html",  
        controller: "AirportInfoServiceController"  
    })
    .when("/Errors", {  
        templateUrl: "Errors.html",  
        controller: "ErrorController"  
    })
     .when("/AboutUs", {  
        templateUrl: "AboutUs.html",  
        controller: "AboutUsController"  
    })
	  .when("/CreateUser",{
		templateUrl: "CreateUser.html",  
        controller: "CreateUserController"  
	  })
	  .when("/CreateUser",{
		templateUrl: "CreateUser.html",  
        controller: "CreateUserController"  
	  })
	  .when("/Flows",{
		templateUrl: "Flows.html",  
        controller: "flowsController"  
	  })
    .otherwise({redirectTo: "/"})
})

app.config(['$locationProvider', function($locationProvider){$locationProvider.hashPrefix('');}]); 

var themeFunction = function($mdThemingProvider){
console.log("theme loaded")
var customPrimary = {
        '50': 'fde4e5',
  '100': 'fabbbd',
  '200': 'f68d92',
  '300': 'f25f66',
  '400': 'f03d45',
  '500': 'ed1b24',
  '600': 'eb1820',
  '700': 'e8141b',
  '800': 'e51016',
  '900': 'e0080d',
  'A100': 'ffffff',
  'A200': 'ffd6d7',
  'A400': 'ed1b24',
  'A700': 'f25f66',
  'contrastDefaultColor': 'light',
  'contrastDarkColors': [
    '50',
    '100',
    '200',
    '300',
    'A100',
    'A200',
    'A400',
    'A700'
  ],
  'contrastLightColors': [
    '400',
    '500',
    '600',
    '700',
    '800',
    '900'
  ]
    };
    $mdThemingProvider
        .definePalette('customPrimary', 
                        customPrimary);

    var customAccent = {
        '50': '#000a08',
        '100': '#00231d',
        '200': '#003d31',
        '300': '#005646',
        '400': '#00705a',
        '500': '#00896f',
        '600': '#00bc97',
        '700': '#00d6ac',
        '800': '#00efc0',
        '900': '#0affcf',
        'A100': '#00bc97',
        'A200': '#00a383',
        'A400': '#00896f',
        'A700': '#23ffd4'
    };
    $mdThemingProvider
        .definePalette('customAccent', 
                        customAccent);

    var customWarn = {
        '50': '#ff7b82',
        '100': '#ff626a',
        '200': '#ff4852',
        '300': '#ff2f3a',
        '400': '#ff1522',
        '500': '#fb000d',
        '600': '#e1000c',
        '700': '#c8000a',
        '800': '#ae0009',
        '900': '#950008',
        'A100': '#ff959a',
        'A200': '#ffaeb3',
        'A400': '#ffc8cb',
        'A700': '#7b0006'
    };
    $mdThemingProvider
        .definePalette('customWarn', 
                        customWarn);

    var customBackground = {
       
		'50': '#ffffff',
        '100': '#ffffff',
        '200': '#ECEFF1',
        '300': '#ffffff',
        '400': '#ffffff',
        '500': '#fff',
        '600': '#f2f2f2',
        '700': '#e6e6e6',
        '800': '#333333',
        '900': '#333333',
        'A100': '#ffffff',
        'A200': '#ffffff',
        'A400': '#ffffff',
        'A700': '#bfbfbf'
    };
    $mdThemingProvider
        .definePalette('customBackground', 
                        customBackground);

   $mdThemingProvider.theme('default')
       .primaryPalette('customPrimary')
	   .accentPalette('customPrimary')
       
}
app.config(themeFunction);
 
 
 
}());


