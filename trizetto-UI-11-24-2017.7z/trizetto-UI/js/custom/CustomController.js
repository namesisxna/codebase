var app=angular.module("HomePageView");
var mainfunction = function($scope,$http,$httpParamSerializerJQLike,$location,$window,$route,$mdToast,$mdDialog,AppData,ModuleData,FileData,FormatData,FunctionData){
		$scope.getAllAppData = function(){
	  		$scope.value=null
		  		$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
	  			}).then(
	  				       function(response){
							   value = response.data;
							   AppData.addAllData(value);
							   window.location = "#/Application";
	  				         },
	  				         function(response){
	  				         }
	  				      );
		}
		
		$scope.getAllModuleData = function(){
		console.log("for test");
	  		$scope.value=null
		  		$http({
	  				method : 'GET',
	  				url : 'https://angular-data-grid.github.io/demo/data.json',
	  			}).then(
	  				       function(response){
							   value = response.data;
							   ModuleData.addAllData(value);
							   window.location = "#/Module";
	  				         },
	  				         function(response){
	  				         }
	  				      );
		}
		$scope.getAllFileData = function() {
        $scope.value = null
        $http({
            method: 'GET',
            url: 'https://angular-data-grid.github.io/demo/data.json',
        }).then(
            function(response) {
                value = response.data;
                FileData.addAllData(value);
                window.location = "#/File";
            },
            function(response) {}
        );
    }
	
	$scope.getAllFormatData = function() {
        $scope.value = null
        $http({
            method: 'GET',
            url: 'https://angular-data-grid.github.io/demo/data.json',
        }).then(
            function(response) {
                value = response.data;
                FormatData.addAllData(value);
                window.location = "#/Format";
            },
            function(response) {}
        );
    }
	
	$scope.getAllFunctionData = function(){
	  		$scope.value=null
		  		$http({
	  				method : 'GET',
	  				url : 'http://10.227.85.208:8071/framework/functions',
	  			}).then(
	  				       function(response){
							   value = response.data;
							   FunctionData.addAllData(value);
							   window.location = "#/Function";
	  				         },
	  				         function(response){
	  				         }
	  				      );
		}
			
			}
app.controller("HomePageController" , mainfunction );

