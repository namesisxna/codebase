var app=angular.module("HomePageView");
var mainfunction = function ($scope,$http,$httpParamSerializerJQLike,$location,$window,$route,$mdToast,$mdDialog) {
		$scope.entities =[
                { name: "Applications" },
                { name: "Layouts" },
				{ name: "Procedures" },
				{ name: "Proc-Seq" },
				{ name: "Segments" },
				{ name: "Fields" },
				{ name: "Files" },
				{ name: "Formats" },
				{ name: "Functions" },
				{ name: "Modules" },
				{ name: "Param-exp" },
				{ name: "Parameters" }				
            ];
		$scope.test = function(value){
		alert(value.name);
		}
}
	
app.controller("Multilevel", mainfunction)