var app = angular.module("HomePageView");
app.service('ModuleData', function($window) {
    var KEY = 'Module.SelectedUserValue1';
	var KEY1 = 'Module.SelectedUserValue11';
	var KEY2 = 'Module.SelectedUserValue12';
	var KEY3 = 'Module.SelectedUserValue13';
    var addAllData = function(newObj1) {
    	localStorage.removeItem(KEY);
        $window.sessionStorage.setItem(KEY, JSON.stringify(newObj1));
    };
    var getAllData = function(){
        var mydata1 = $window.sessionStorage.getItem(KEY);
        if (mydata1) {
            mydata1 = JSON.parse(mydata1);  
        }
        return mydata1 || [];
    };
	var addDataById = function(newObj1) {
    	localStorage.removeItem(KEY1);
        $window.sessionStorage.setItem(KEY1, JSON.stringify(newObj1));
    };
    var getDataById = function(){
        var mydata1 = $window.sessionStorage.getItem(KEY1);
        if (mydata1) {
            mydata1 = JSON.parse(mydata1);  
        }
        return mydata1 || [];
    };
	var addUpdateData = function(newObj1) {
    	localStorage.removeItem(KEY2);
        $window.sessionStorage.setItem(KEY2, JSON.stringify(newObj1));
    };
    var getUpdateData = function(){
        var mydata1 = $window.sessionStorage.getItem(KEY2);
        if (mydata1) {
            mydata1 = JSON.parse(mydata1);  
        }
        return mydata1 || [];
    };
	var addDeleteData = function(newObj1) {
    	localStorage.removeItem(KEY3);
        $window.sessionStorage.setItem(KEY3, JSON.stringify(newObj1));
    };
    var getDeleteData = function(){
        var mydata1 = $window.sessionStorage.getItem(KEY3);
        if (mydata1) {
            mydata1 = JSON.parse(mydata1);  
        }
        return mydata1 || [];
    };
    return {
        addAllData: addAllData,
        getAllData: getAllData,
		addDataById: addDataById,
		getDataById: getDataById,
		addUpdateData: addUpdateData,
		getUpdateData:getUpdateData,
		addDeleteData: addDeleteData,
		getDeleteData: getDeleteData
    };
});